/**
 * 
 */
/**
 * @author aluno
 *
 */
module projetoDiarista {
}