package br.com.projeto;

import br.com.classes.Cliente;
import br.com.classes.Diarista;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Diarista diarista = new Diarista();
		
		diarista.nome = "João da Silva";
		diarista.telefone = "(11) 98757-7859";
		diarista.endereco = "Av Cajamar, N 111";
		
		System.out.println("Nome Diarista: " + diarista.nome);
		System.out.println("Telefone Diarista: " + diarista.telefone);
		System.out.println("Endereço Diarista: " + diarista.endereco);
		diarista.atender("José");
		
		System.out.println("====================================================================");
		
		Cliente cliente = new Cliente();
		
		cliente.nome =  "Denis";
		cliente.telefone = "(11) 98568-8974";
		cliente.endereco = "Rua das Américas";
		cliente.saldo = 100;
		
		System.out.println("Nome Cliente: " + cliente.nome);
		System.out.println("Telefone Cliente: " + cliente.telefone);
		System.out.println("Endereço Cliente: " + cliente.endereco);
		System.out.println("Saldo Cliente: " + cliente.saldo);
						
	}

}
