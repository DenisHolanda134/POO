package br.com.classes;

public class Cliente extends Pessoas {

	public String nome;
	
	public String telefone;
	
	public String endereco;
	
	public double saldo;
	
}


