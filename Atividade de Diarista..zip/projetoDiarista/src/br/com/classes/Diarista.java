package br.com.classes;

public class Diarista extends Pessoas{
	
	public String nome;
	public String telefone;
	public String endereco;
	public String chavePix;

	public void atender(String nomeCliente) {
	
		System.out.println("Realizando atendimento para cliente: " + nomeCliente);
		
    }
	
}