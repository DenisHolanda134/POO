package br.com.mercadolivre;

public class veiculo {

	//Atributos
	public String nome;
	public String cor;
	
	public String rodas; 
	public String motor;
	public float velocidade;
	
	//ações
	public void ligar() {

		System.out.println("O carro ligou!");
	}

	public void desligar() {
		
		System.out.println("O carro desligou!");
	}
}